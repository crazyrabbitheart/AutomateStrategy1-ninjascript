#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private SMMA[] cacheSMMA;

		
		public SMMA SMMA(int period)
		{
			return SMMA(Input, period);
		}


		
		public SMMA SMMA(ISeries<double> input, int period)
		{
			if (cacheSMMA != null)
				for (int idx = 0; idx < cacheSMMA.Length; idx++)
					if (cacheSMMA[idx].Period == period && cacheSMMA[idx].EqualsInput(input))
						return cacheSMMA[idx];
			return CacheIndicator<SMMA>(new SMMA(){ Period = period }, input, ref cacheSMMA);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.SMMA SMMA(int period)
		{
			return indicator.SMMA(Input, period);
		}


		
		public Indicators.SMMA SMMA(ISeries<double> input , int period)
		{
			return indicator.SMMA(input, period);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.SMMA SMMA(int period)
		{
			return indicator.SMMA(Input, period);
		}


		
		public Indicators.SMMA SMMA(ISeries<double> input , int period)
		{
			return indicator.SMMA(input, period);
		}

	}
}

#endregion
