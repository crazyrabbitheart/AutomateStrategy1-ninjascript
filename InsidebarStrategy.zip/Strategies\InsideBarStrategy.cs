#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class InsideBarStrategy : Strategy
	{
		private SMMA smma;
		private ATR atr;
		private double TP;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "InsideBarStrategy";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				StartTime						= DateTime.Parse("07:00", System.Globalization.CultureInfo.InvariantCulture);
				EndTime							= DateTime.Parse("17:00", System.Globalization.CultureInfo.InvariantCulture);
				NoTradingStartTime				= DateTime.Parse("07:30", System.Globalization.CultureInfo.InvariantCulture);
				NoTradingEndTime				= DateTime.Parse("07:35", System.Globalization.CultureInfo.InvariantCulture);
				Offset							= 48;
				SL								= 40;				
				Lookback						= 10;
				ShowATR							= true;
				
				if (ShowATR){
					AddPlot(Brushes.Red, "ATRLow");
					AddPlot(Brushes.Green, "ATRHigh");
				}
			}
			else if (State == State.Configure)
			{
				SetStopLoss(CalculationMode.Ticks, SL);
			}
			else if (State == State.DataLoaded){
				smma = SMMA(14);
				atr = ATR(14);				
				AddChartIndicator (smma);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom strategy logic here.
			
			if (CurrentBar < BarsRequiredToTrade)		return;
			
			ATRHigh[0] = High[0] + atr[0] * 1.5;
			ATRLow[0] = Low[0] - atr[0] * 1.5;
			
			
//			if (Position.MarketPosition == MarketPosition.Flat)
//			{
//				SetProfitTarget("long", CalculationMode.Ticks, 100, false);
//				SetProfitTarget("short", CalculationMode.Ticks, 100, false);
//			}
//			else if (Position.MarketPosition == MarketPosition.Long)
//			{
//				// Once the price is greater than entry price+10 ticks, set stop loss to breakeven
//				if (Close[0] > Position.AveragePrice + 10 * TickSize)
//				{
//					SetStopLoss("entry1", CalculationMode.Price, Position.AveragePrice, false);
//				}
				
//				// Once the price is greater than entry price+15 ticks, set stop loss to breakeven
//				if (Close[0] > Position.AveragePrice + 15 * TickSize)
//				{
//					SetStopLoss("entry2", CalculationMode.Price, Position.AveragePrice, false);
//				}
//			}
			
			if (!(ToTime(Time[0]) >= ToTime(StartTime) && ToTime(Time[0]) <= ToTime(EndTime)))					return;
			if (ToTime(Time[0]) >= ToTime(NoTradingStartTime) && ToTime(Time[0]) <= ToTime(NoTradingEndTime))	return;
			
			if (High[1] > High[0] && Low[1] < Low[0] && Position.MarketPosition == MarketPosition.Flat){
				BarBrushes[0] = Brushes.Yellow;
				if (Close[0] > smma[0]){					
					EnterLongLimit(0, true, DefaultQuantity, High[0] + Offset * TickSize, "long");
					if (High[Lookback] > High[0]){
						SetProfitTarget("long", CalculationMode.Price, High[Lookback], false);
//						TP = High[Lookback];
					}else{
						SetProfitTarget("long", CalculationMode.Price, ATRHigh[0], false);
//						TP = ATRHigh[0];
					}
				}
				
				if (Close[0] < smma[0]){
					EnterShortLimit(0, true, DefaultQuantity, Low[0] - Offset * TickSize, "short");
					if (Low[Lookback] < Low[0]){
						SetProfitTarget("short", CalculationMode.Price, Low[Lookback], false);
//						TP = Low[Lookback];
					}else{
						SetProfitTarget("short", CalculationMode.Price, ATRLow[0], false);
//						TP = ATRLow[0];
					}
				}
			}
			
//			if (Position.MarketPosition == MarketPosition.Long){
//				SetProfitTarget("long", CalculationMode.Price, TP, false);
//			}else if(Position.MarketPosition == MarketPosition.Short){
//				SetProfitTarget("short", CalculationMode.Price, TP, false);
//			}
			
		}

		#region Properties
		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="StartTime", Order=1, GroupName="Parameters")]
		public DateTime StartTime
		{ get; set; }

		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="EndTime", Order=2, GroupName="Parameters")]
		public DateTime EndTime
		{ get; set; }

		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="NoTradingStartTime", Order=3, GroupName="Parameters")]
		public DateTime NoTradingStartTime
		{ get; set; }

		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="NoTradingEndTime", Order=4, GroupName="Parameters")]
		public DateTime NoTradingEndTime
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Offset", Order=5, GroupName="Parameters")]
		public int Offset
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="SL", Order=6, GroupName="Parameters")]
		public int SL
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Lookback", Order=7, GroupName="Parameters")]
		public int Lookback
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="ShowATR", Order=8, GroupName="Parameters")]
		public bool ShowATR
		{ get; set; }
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ATRLow
		{
		  get { return Values[0]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ATRHigh
		{
		  get { return Values[1]; }
		}
		#endregion
	}
}
